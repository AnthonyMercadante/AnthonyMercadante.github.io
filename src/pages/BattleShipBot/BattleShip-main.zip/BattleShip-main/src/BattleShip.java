import BattleShipAPI.BattleShipAPI;
public class BattleShip {
    public static void main(String[] args) {


        final int NUMBEROFGAMES = 10000;
        System.out.println(BattleShipAPI.getVersion());
        BattleShipAPI battleShip = new BattleShipAPI(NUMBEROFGAMES, new BattleShipAI());
        int [] gameResults = battleShip.run();

        battleShip.reportResults();
    }
}
