package BattleShipAPI;

public enum ShipOrientation {
    Vertical,
    Horizontal;

    private ShipOrientation() {
    }
}
