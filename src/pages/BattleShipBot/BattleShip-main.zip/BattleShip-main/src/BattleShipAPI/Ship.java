package BattleShipAPI;

import java.awt.Point;
import java.util.ArrayList;
import java.util.Iterator;

public final class Ship {
    private boolean isPlaced = false;
    private Point location;
    private ShipOrientation orientation;
    private int length;

    public Ship(int length, Point location, ShipOrientation orientation) {
        if (length <= 0) {
            throw new IllegalArgumentException("Invalid length specified: must be >= 1 ");
        } else {
            this.length = length;
            this.location = location;
            this.orientation = orientation;
        }
    }

    public boolean getIsPlaced() {
        return this.isPlaced;
    }

    public Point getLocation() {
        return this.location;
    }

    public ShipOrientation getOrientation() {
        return this.orientation;
    }

    public int getLength() {
        return this.length;
    }

    public static boolean place(int boardSize, Ship newShip, ArrayList<Ship> ships) {
        newShip.isPlaced = false;
        if (!newShip.isValid(boardSize)) {
            return false;
        } else {
            if (ships != null) {
                Iterator var3 = ships.iterator();

                label97:
                while(true) {
                    while(true) {
                        if (!var3.hasNext()) {
                            break label97;
                        }

                        Ship ship = (Ship)var3.next();
                        int x;
                        int y;
                        if (ship.orientation == ShipOrientation.Horizontal) {
                            x = ship.getLocation().y;

                            for(y = ship.getLocation().x; y < ship.getLocation().x + ship.getLength(); ++y) {
                                if (y == ship.getLocation().x && y > 0 && newShip.isAt(new Point(y - 1, x))) {
                                    return false;
                                }

                                if (y == ship.getLocation().x + ship.getLength() - 1 && y < boardSize - 1 && newShip.isAt(new Point(y + 1, x))) {
                                    return false;
                                }

                                if (newShip.isAt(new Point(y, x)) || newShip.isAt(new Point(y, Math.max(0, x - 1))) || newShip.isAt(new Point(y, Math.min(boardSize - 1, x + 1)))) {
                                    return false;
                                }
                            }
                        } else if (ship.orientation == ShipOrientation.Vertical) {
                            x = ship.getLocation().x;

                            for(y = ship.getLocation().y; y < ship.getLocation().y + ship.getLength(); ++y) {
                                if (y == ship.getLocation().y && y > 0 && newShip.isAt(new Point(x, y - 1))) {
                                    return false;
                                }

                                if (y == ship.getLocation().y + ship.getLength() - 1 && y < boardSize - 1 && newShip.isAt(new Point(x, y + 1))) {
                                    return false;
                                }

                                if (newShip.isAt(new Point(x, y)) || newShip.isAt(new Point(Math.max(0, x - 1), y)) || newShip.isAt(new Point(Math.min(boardSize - 1, x + 1), y))) {
                                    return false;
                                }
                            }
                        }
                    }
                }
            }

            newShip.isPlaced = true;
            return true;
        }
    }

    public boolean isAt(Point p) {
        if (this.getOrientation() == ShipOrientation.Horizontal) {
            return p.y == this.location.y && p.x >= this.location.x && p.x < this.location.x + this.length;
        } else {
            return p.x == this.location.x && p.y >= this.location.y && p.y < this.location.y + this.length;
        }
    }

    public boolean isValid(int boardSize) {
        if (this.location.x >= 0 && this.location.y >= 0) {
            if (this.orientation == ShipOrientation.Horizontal) {
                if (this.location.y >= boardSize || this.location.x + this.length > boardSize) {
                    return false;
                }
            } else if (this.location.x >= boardSize || this.location.y + this.length > boardSize) {
                return false;
            }

            return true;
        } else {
            return false;
        }
    }
}
