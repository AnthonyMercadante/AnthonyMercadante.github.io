package BattleShipAPI;

public interface BattleShipBot {
    void initialize(BattleShipAPI var1);

    void fireShot();

    String getAuthors();
}
