package BattleShipAPI;

import java.awt.Point;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class BattleShipAPI {
    private static final boolean DEBUGMODE = false;
    public static final int BOARD_SIZE = 10;
    public static final int[] SHIP_SIZES = new int[]{5, 4, 3, 2, 2, 1, 1};
    private int numberOfGames;
    private int boardSize;
    private boolean success;
    private int[] shipSizes;
    private CellState[][] board;
    private ArrayList<Ship> ships;
    private ArrayList<Point> hits;
    private ArrayList<Point> misses;
    private Random random = new Random(-1412567296L);
    private int totalShots;
    private long timeRequired;
    private BattleShipBot bot;

    public static String getVersion() {
        return "B A T T L E S H I P - Version 3.0 [January 23,2024]";
    }

    public BattleShipAPI(int numberOfGames, BattleShipBot bot) {
        this.bot = bot;
        this.numberOfGames = numberOfGames;
        this.success = false;
        this.boardSize = 10;
        this.reset();
        bot.initialize(this);
    }

    public int[] run() {
        long start = System.nanoTime();
        this.totalShots = 0;
        int[] gameScores = new int[this.numberOfGames];
        this.success = false;

        try {
            for(int game = 0; game < this.numberOfGames; ++game) {
                this.reset();
                this.bot.initialize(this);

                while(!this.allSunk()) {
                    this.bot.fireShot();
                }

                int gameShots = this.totalShotsTaken();
                gameScores[game] = gameShots;
                this.totalShots += gameShots;
                this.success = true;
            }
        } catch (Exception var6) {
            System.out.println("RUNNING of Solution Failed " + this.bot.getClass());
            System.out.println(var6.getMessage());
            var6.printStackTrace();
        }

        this.timeRequired = (System.nanoTime() - start) / 1000000L;
        return gameScores;
    }

    public void reportResults() {
        System.out.println("------------------------------------------------------------");
        System.out.printf("BattleShip 2 - Results for %s\n", this.bot.getClass().getName());
        System.out.println("Author : " + this.bot.getAuthors());
        System.out.println("------------------------------------------------------------");
        if (this.success) {
            System.out.printf("The Average Score over %d games    = %.2f\n", this.numberOfGames, (double)this.totalShots / (double)this.numberOfGames);
            System.out.printf("Time required to complete %d games = %d ms\n", this.numberOfGames, this.timeRequired);
        } else {
            System.out.println("Solution did not complete - Exception thrown in code");
        }

        System.out.println("------------------------------------------------------------");
    }

    private void reset() {
        this.hits = new ArrayList();
        this.misses = new ArrayList();
        this.shipSizes = SHIP_SIZES;
        this.board = new CellState[this.boardSize][this.boardSize];

        int i;
        for(i = 0; i < this.boardSize; ++i) {
            for(int y = 0; y < this.boardSize; ++y) {
                this.board[i][y] = CellState.Empty;
            }
        }

        this.ships = new ArrayList();

        for(i = 0; i < this.shipSizes.length; ++i) {
            Ship testShip = null;

            do {
                Point location = new Point(this.random.nextInt(this.boardSize), this.random.nextInt(this.boardSize));
                ShipOrientation orientation = ShipOrientation.values()[this.random.nextInt(ShipOrientation.values().length)];
                testShip = new Ship(this.shipSizes[i], location, orientation);
                boolean placed = Ship.place(this.boardSize, testShip, this.ships);
                if (placed) {
                }
            } while(!testShip.getIsPlaced());

            this.ships.add(testShip);
        }

    }

    public boolean allSunk() {
        int numberOfHitCells = 0;

        for(int y = 0; y < this.boardSize; ++y) {
            for(int x = 0; x < this.boardSize; ++x) {
                if (this.board[x][y] == CellState.Hit) {
                    ++numberOfHitCells;
                }
            }
        }

        return numberOfHitCells == this.totalShipLengths();
    }

    public int totalShotsTaken() {
        return this.hits.size() + this.misses.size();
    }

    public int[] getShipSizes() {
        return this.shipSizes;
    }

    public boolean shoot(Point shot) {
        boolean hit = this.shipAt(shot);
        if (hit) {
            this.board[shot.x][shot.y] = CellState.Hit;
            this.hits.add(shot);
        } else {
            this.board[shot.x][shot.y] = CellState.Miss;
            this.misses.add(shot);
        }

        return this.shipAt(shot);
    }

    public int numberOfShipsSunk() {
        int num = 0;
        Iterator var2 = this.ships.iterator();

        while(var2.hasNext()) {
            Ship s = (Ship)var2.next();
            int length = s.getLength();
            Point pos = s.getLocation();
            boolean sunk = true;
            int y;
            if (s.getOrientation() == ShipOrientation.Horizontal) {
                for(y = 0; y < length; ++y) {
                    sunk &= this.board[pos.x + y][pos.y] == CellState.Hit;
                }
            } else {
                for(y = 0; y < length; ++y) {
                    sunk &= this.board[pos.x][pos.y + y] == CellState.Hit;
                }
            }

            if (sunk) {
                ++num;
            }
        }

        return num;
    }

    private boolean shipAt(Point p) {
        Iterator var2 = this.ships.iterator();

        Ship s;
        do {
            if (!var2.hasNext()) {
                return false;
            }

            s = (Ship)var2.next();
        } while(!s.isAt(p));

        return true;
    }

    private void printBoard() {
        System.out.print("\n.  ");

        int y;
        for(y = 0; y < this.boardSize; ++y) {
            System.out.printf("%2d ", y);
        }

        for(y = 0; y < this.boardSize; ++y) {
            System.out.printf("\n%2d ", y);

            for(int x = 0; x < this.boardSize; ++x) {
                System.out.printf(" %s ", this.board[x][y]);
            }
        }

        System.out.println();
    }

    private void debugPrintBoard() {
        CellState[][] dboard = new CellState[this.boardSize][this.boardSize];

        int y;
        int x;
        for(y = 0; y < this.boardSize; ++y) {
            for(x = 0; x < this.boardSize; ++x) {
                if (this.shipAt(new Point(y, x))) {
                    dboard[y][x] = CellState.Hit;
                } else {
                    dboard[y][x] = CellState.Empty;
                }
            }
        }

        System.out.print("\n.  ");

        for(y = 0; y < this.boardSize; ++y) {
            System.out.printf("%2d ", y);
        }

        for(y = 0; y < this.boardSize; ++y) {
            System.out.printf("\n%2d ", y);

            for(x = 0; x < this.boardSize; ++x) {
                System.out.printf(" %s ", dboard[x][y]);
            }
        }

        System.out.println();
    }

    private int totalShipLengths() {
        int length = 0;

        Ship s;
        for(Iterator var2 = this.ships.iterator(); var2.hasNext(); length += s.getLength()) {
            s = (Ship)var2.next();
        }

        return length;
    }

    public static void main(String[] args) {
        System.out.println(getVersion());
    }
}